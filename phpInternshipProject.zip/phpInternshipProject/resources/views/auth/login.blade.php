<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | PHP Internship Project (i)</title>
  <link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
    <div class="nav">
        <div class="log">
            <span>Logo</span>
        </div>
        <div class="nav-links">
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="{{ route('auth.register') }}">Signup</a></li>
            </ul>
        </div>
    </div>
  <div class="wrapper">
    <header>Login Form</header>
    <form action="{{ route('auth.check') }}" method="post">
        @if(Session::get('fail'))
               <div class="errortextfield">
                  {{ Session::get('fail') }}
               </div>
            @endif
            
           @csrf
      <div class="field email">
        <div class="input-area">
          <input type="text" name="email" placeholder="Email Address" value="{{ old('email') }}">
          <i class="icon fas fa-envelope"></i>
          
        </div>
        <div class="errortextfield">@error('email'){{ $message }} @enderror</div>
      </div>
      <div class="field password">
        <div class="input-area">
          <input type="password" name="password"  placeholder="Password">
          <i class="icon fas fa-lock"></i>
          
        </div>
        <div class="errortextfield">@error('password'){{ $message }} @enderror</div>
      </div>
      
      <input type="submit" value="Login">
    </form>
    <div class="sign-txt">Not yet member? <a href="{{ route('auth.register') }}">Signup now</a></div>
  </div>
  
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard | </title>
  <link rel="stylesheet" href="<?php echo e(asset('frontend/css/index.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
    <div class="nav">
        <div class="log">
            <span>Logo</span>
        </div>
        <div class="nav-links">
            <ul>
                <li><a href="">Home</a></li>
                
            </ul>
        </div>
    </div>
  <div class="wrapper">
    <header>Dashboard</header>
    
        <div class="field email">
            <h3>Hlo <?php echo e($LoggedUserInfo['name']); ?></h3>
            <br>
            <p><?php echo e($LoggedUserInfo['email']); ?></p>
            <br>
            <p>Here you will get all profile,security and other functionality provided by developer.</p>
            
        </div>
        <div class="sign-txt"><a href="<?php echo e(route('auth.logout')); ?>">Log out</a></div>
  
</body>
</html><?php /**PATH D:\Xampp\htdocs\project\resources\views/auth/dashboard.blade.php ENDPATH**/ ?>